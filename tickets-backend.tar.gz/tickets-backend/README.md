# ✈️ Aviatickets Backend

Backend часть приложения Aviatickets. См. основной [README.md](../README.md) в корне проекта для полной документации.

## 🚀 Быстрый старт

```bash
# Установка зависимостей
npm install

# Настройка переменных окружения
cp .env.example .env
# Отредактируйте .env с вашими данными

# Запуск в режиме разработки
npm run start:dev

# Сборка для production
npm run build
npm run start:prod
```

## 📚 API Документация

После запуска сервера Swagger документация доступна по адресу:
- `http://localhost:3000/api`

## 🔧 Переменные окружения

См. `.env.example` для подробных инструкций по настройке.

Основные переменные:
- `MONGO_URI` - подключение к MongoDB
- `JWT_SECRET` - секретный ключ для JWT токенов
- `ONELYA_*` - настройки Onelya API
- `GOOGLE_CLIENT_ID` - для Google OAuth

Подробная документация в основном [README.md](../README.md).
npm run lint       # Проверка кода линтером
npm run format     # Форматирование кода
npm test           # Запуск тестов
```

## 📝 Структура проекта

```
src/
├── app.module.ts          # Главный модуль приложения
├── main.ts                # Точка входа
├── auth/                  # Модуль авторизации
├── booking/               # Модуль бронирования
│   ├── booking.controller.ts
│   ├── booking.service.ts
│   └── booking.module.ts
├── flights/               # Модуль поиска рейсов
│   ├── flights.controller.ts
│   ├── flights.service.ts
│   └── flights.module.ts
└── providers/             # Провайдеры внешних API
```

## 🔒 Безопасность

- Не коммитьте файл `.env` в репозиторий
- Используйте сильные пароли для JWT_SECRET
- Настройте CORS для production
- Используйте HTTPS в production