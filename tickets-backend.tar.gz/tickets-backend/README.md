# ✈️ Aviatickets Backend (Demo)

## 📘 Описание
Mock-backend для демонстрации архитектуры поиска и бронирования авиабилетов.
Поддерживает поиск рейсов, бронирование, получение PDF и авторизацию.
Создан на NestJS (Node.js + TypeScript).

## 🚀 Локальный запуск

### Установка зависимостей
```bash
npm install
```

### Настройка переменных окружения
```bash
cp .env.example .env
# Отредактируйте .env с вашими данными
```

### Запуск в режиме разработки
```bash
npm run start:dev
```

### Сборка для production
```bash
npm run build
npm run start:prod
```

## 🐳 Запуск через Docker

```bash
docker-compose up --build
```

Или через Dockerfile:
```bash
docker build -t aviatickets-backend .
docker run -p 3000:3000 --env-file .env aviatickets-backend
```

## 📦 Деплой на сервер

Подробные инструкции по деплою на Timeweb и другие платформы см. в [DEPLOY.md](./DEPLOY.md)

## 🔧 Переменные окружения

См. `.env.example` для списка всех переменных окружения.

Основные:
- `PORT` - порт сервера (по умолчанию 3000)
- `ONELYA_BASE_URL` - URL API Onelya
- `ONELYA_LOGIN` - логин для Onelya API
- `ONELYA_PASSWORD` - пароль для Onelya API
- `ONELYA_POS` - POS ID для Onelya API

## 📚 API Документация

После запуска сервера Swagger документация доступна по адресу:
- `http://localhost:3000/api`

## 🛠️ Полезные команды

```bash
npm run build      # Сборка проекта
npm run start      # Запуск в production режиме
npm run start:dev  # Запуск в режиме разработки с hot-reload
npm run lint       # Проверка кода линтером
npm run format     # Форматирование кода
npm test           # Запуск тестов
```

## 📝 Структура проекта

```
src/
├── app.module.ts          # Главный модуль приложения
├── main.ts                # Точка входа
├── auth/                  # Модуль авторизации
├── booking/               # Модуль бронирования
│   ├── booking.controller.ts
│   ├── booking.service.ts
│   └── booking.module.ts
├── flights/               # Модуль поиска рейсов
│   ├── flights.controller.ts
│   ├── flights.service.ts
│   └── flights.module.ts
└── providers/             # Провайдеры внешних API
```

## 🔒 Безопасность

- Не коммитьте файл `.env` в репозиторий
- Используйте сильные пароли для JWT_SECRET
- Настройте CORS для production
- Используйте HTTPS в production