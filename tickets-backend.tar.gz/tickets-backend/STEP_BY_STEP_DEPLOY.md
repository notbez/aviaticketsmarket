# 📋 ПОШАГОВАЯ ИНСТРУКЦИЯ ПО ДЕПЛОЮ НА TIMEWEB

## 📁 АНАЛИЗ ПРОЕКТА

Ваш проект состоит из двух частей:

1. **aviatickets-demo/** - React Native мобильное приложение (frontend)
   - ❌ НЕ загружается на сервер
   - Работает на телефоне/планшете
   - Обращается к backend через API

2. **tickets-backend/** - NestJS сервер (backend)
   - ✅ ЭТО НУЖНО ЗАГРУЗИТЬ НА СЕРВЕР
   - Предоставляет API для мобильного приложения

---

## 🎯 ЧТО НУЖНО ЗАГРУЗИТЬ НА СЕРВЕР

**ТОЛЬКО ПАПКУ: `tickets-backend`**

---

## 📝 ПОШАГОВАЯ ИНСТРУКЦИЯ

### ШАГ 1: Откройте терминал на вашем компьютере

**На Mac:**
- Нажмите `Cmd + Space` (поиск Spotlight)
- Введите "Terminal" и нажмите Enter

**На Windows:**
- Нажмите `Win + R`
- Введите `cmd` и нажмите Enter

---

### ШАГ 2: Перейдите в папку с проектом

В терминале выполните:

```bash
cd /Users/vlasovmihail/Documents/aviatickets.nosync
```

Проверьте, что вы в правильной папке:
```bash
ls
```

Должны увидеть:
- `aviatickets-demo/`
- `tickets-backend/`

---

### ШАГ 3: Перейдите в папку tickets-backend

```bash
cd tickets-backend
```

Проверьте содержимое:
```bash
ls
```

Должны увидеть:
- `src/`
- `package.json`
- `Dockerfile`
- `README.md`
- и другие файлы

---

### ШАГ 4: Соберите проект локально (проверка)

```bash
npm install
npm run build
```

Если всё прошло успешно, значит проект готов к загрузке.

---

### ШАГ 5: Подготовьте файлы для загрузки

**Вариант A: Через SFTP (FileZilla, WinSCP, Cyberduck)**

1. Откройте SFTP клиент (FileZilla, WinSCP, Cyberduck)
2. Подключитесь к серверу Timeweb:
   - Хост: `ваш_сервер.timeweb.ru` или IP адрес
   - Порт: `22` (SSH/SFTP)
   - Пользователь: ваш логин
   - Пароль: ваш пароль

**Вариант B: Через терминал (scp)**

Оставьте терминал открытым, перейдём к следующему шагу.

---

### ШАГ 6: Подключитесь к серверу Timeweb через SSH

В терминале выполните:

```bash
ssh ваш_пользователь@ваш_сервер.timeweb.ru
```

**Пример:**
```bash
ssh user123@server123.timeweb.ru
```

Если спросит подтверждение, введите `yes` и нажмите Enter.
Затем введите пароль.

---

### ШАГ 7: Создайте директорию на сервере

После подключения к серверу выполните:

```bash
# Перейдите в домашнюю директорию
cd ~

# Создайте папку для проекта
mkdir -p aviatickets-backend

# Перейдите в неё
cd aviatickets-backend

# Проверьте, что вы в правильной директории
pwd
```

Должен показать путь типа: `/home/ваш_пользователь/aviatickets-backend`

---

### ШАГ 8: Загрузите файлы на сервер

**Вариант A: Через SFTP клиент (FileZilla/WinSCP)**

1. В левой части (локальный компьютер) перейдите в:
   ```
   /Users/vlasovmihail/Documents/aviatickets.nosync/tickets-backend
   ```

2. В правой части (сервер) перейдите в:
   ```
   /home/ваш_пользователь/aviatickets-backend
   ```

3. Выделите ВСЕ файлы и папки из `tickets-backend` (кроме `node_modules` и `dist` - их можно не загружать)
4. Перетащите их в правую часть (на сервер)

**Вариант B: Через терминал (scp)**

Откройте НОВЫЙ терминал на вашем компьютере (не закрывая SSH соединение) и выполните:

```bash
cd /Users/vlasovmihail/Documents/aviatickets.nosync

scp -r tickets-backend/* ваш_пользователь@ваш_сервер.timeweb.ru:~/aviatickets-backend/
```

**Пример:**
```bash
scp -r tickets-backend/* user123@server123.timeweb.ru:~/aviatickets-backend/
```

---

### ШАГ 9: Вернитесь в SSH терминал и проверьте загрузку

В терминале, где вы подключены к серверу, выполните:

```bash
cd ~/aviatickets-backend
ls -la
```

Должны увидеть файлы проекта:
- `src/`
- `package.json`
- `Dockerfile`
- и другие

---

### ШАГ 10: Установите зависимости на сервере

```bash
# Убедитесь, что вы в правильной директории
cd ~/aviatickets-backend

# Установите зависимости
npm install --production
```

---

### ШАГ 11: Создайте файл .env

```bash
# Создайте .env файл из примера
cp .env.example .env

# Откройте для редактирования
nano .env
```

В файле укажите:
```env
PORT=3000
ONELYA_BASE_URL=https://test.onelya.ru/api
ONELYA_LOGIN=ваш_логин_onelya
ONELYA_PASSWORD=ваш_пароль_onelya
ONELYA_POS=ваш_pos_id
NODE_ENV=production
```

**Как редактировать в nano:**
- Внесите изменения
- Нажмите `Ctrl + O` (сохранить)
- Нажмите `Enter` (подтвердить)
- Нажмите `Ctrl + X` (выйти)

---

### ШАГ 12: Соберите проект на сервере

```bash
npm run build
```

Должно завершиться без ошибок.

---

### ШАГ 13: Установите PM2 (менеджер процессов)

```bash
npm install -g pm2
```

---

### ШАГ 14: Запустите приложение через PM2

```bash
# Запустите приложение
pm2 start ecosystem.config.js

# Сохраните конфигурацию
pm2 save

# Настройте автозапуск при перезагрузке сервера
pm2 startup
```

Выполните команду, которую покажет `pm2 startup` (обычно что-то вроде `sudo env PATH=...`)

---

### ШАГ 15: Проверьте работу приложения

```bash
# Проверьте статус
pm2 status

# Посмотрите логи
pm2 logs aviatickets-backend

# Проверьте, что сервер отвечает
curl http://localhost:3000/api
```

---

### ШАГ 16: Настройте домен (если есть)

Если у вас есть домен, настройте его в панели Timeweb, чтобы он указывал на ваш сервер.

---

## ✅ ГОТОВО!

Ваш backend теперь работает на сервере!

**Проверьте:**
- API: `http://ваш_домен.ru/api` (Swagger документация)
- Главная: `http://ваш_домен.ru/`

---

## 🔄 ОБНОВЛЕНИЕ ПРОЕКТА (когда нужно обновить код)

1. На локальном компьютере внесите изменения
2. Загрузите обновлённые файлы на сервер (через SFTP или scp)
3. На сервере выполните:

```bash
cd ~/aviatickets-backend
npm install --production
npm run build
pm2 restart aviatickets-backend
```

---

## 📱 ОБНОВЛЕНИЕ АДРЕСА API В МОБИЛЬНОМ ПРИЛОЖЕНИИ

После деплоя нужно обновить адрес API в мобильном приложении:

1. Откройте файл: `aviatickets-demo/constants/api.js`
2. Замените адрес на ваш новый:

```javascript
export const API_BASE = 'http://ваш_домен.ru';
// или
export const API_BASE = 'https://ваш_домен.ru'; // если настроен SSL
```

3. Также обновите в файле `aviatickets-demo/screens/BookingScreen.js` (строка 18)

---

## 🆘 ЕСЛИ ЧТО-ТО НЕ РАБОТАЕТ

1. Проверьте логи: `pm2 logs aviatickets-backend`
2. Проверьте статус: `pm2 status`
3. Проверьте, что порт 3000 открыт в firewall Timeweb
4. Проверьте переменные окружения: `cat .env`
5. Перезапустите: `pm2 restart aviatickets-backend`

---

## 📞 ПОЛЕЗНЫЕ КОМАНДЫ

```bash
pm2 list                    # Список всех процессов
pm2 logs aviatickets-backend # Просмотр логов
pm2 restart aviatickets-backend # Перезапуск
pm2 stop aviatickets-backend   # Остановка
pm2 delete aviatickets-backend # Удаление
```

