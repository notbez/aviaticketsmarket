# ⚡ Быстрый деплой на Timeweb

## 🎯 Определение директории на сервере

### 1. Подключитесь к серверу:
```bash
ssh ваш_пользователь@ваш_сервер.timeweb.ru
```

### 2. Узнайте, где вы находитесь:
```bash
pwd  # Покажет текущую директорию
```

### 3. Выберите директорию в зависимости от типа хостинга:

#### ✅ VPS/Выделенный сервер (лучший вариант):
```bash
cd ~
mkdir -p aviatickets-backend
cd aviatickets-backend
# Путь: /home/ваш_пользователь/aviatickets-backend
```

#### ✅ Виртуальный хостинг:
```bash
cd ~/public_html
# или
cd ~/www
mkdir -p aviatickets-backend
cd aviatickets-backend
```

#### ✅ Node.js хостинг Timeweb:
Проверьте в панели управления Timeweb → раздел "Node.js приложения"
Обычно директория указана там, например: `~/node-apps/ваше_приложение`

## 📦 Быстрая загрузка проекта

### Вариант 1: Через Git (если есть репозиторий)
```bash
cd ~/aviatickets-backend  # или ваша директория
git clone https://github.com/ваш_репозиторий.git .
cd tickets-backend
```

### Вариант 2: Через SFTP (FileZilla, WinSCP)
1. Подключитесь к серверу через SFTP
2. Перейдите в `~/aviatickets-backend` (или вашу директорию)
3. Загрузите всю папку `tickets-backend` из локального проекта

## 🚀 Установка и запуск

```bash
# Перейдите в директорию проекта
cd ~/aviatickets-backend/tickets-backend

# Установите зависимости
npm install --production

# Создайте .env файл
cp .env.example .env
nano .env  # Заполните переменные окружения

# Соберите проект
npm run build

# Установите PM2 (если еще не установлен)
npm install -g pm2

# Запустите приложение
pm2 start ecosystem.config.js
pm2 save
pm2 startup
```

## ✅ Проверка

```bash
# Проверьте статус
pm2 status

# Посмотрите логи
pm2 logs aviatickets-backend

# Проверьте работу API
curl http://localhost:3000/api
```

## 📝 Важные пути

- **Директория проекта:** `~/aviatickets-backend/tickets-backend`
- **Скомпилированные файлы:** `~/aviatickets-backend/tickets-backend/dist`
- **Файл конфигурации:** `~/aviatickets-backend/tickets-backend/.env`
- **Логи PM2:** `~/.pm2/logs/`

## 🔄 Обновление проекта

```bash
cd ~/aviatickets-backend/tickets-backend
git pull  # или загрузите новые файлы через SFTP
npm install --production
npm run build
pm2 restart aviatickets-backend
```

