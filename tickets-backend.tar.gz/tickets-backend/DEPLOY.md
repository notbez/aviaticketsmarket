# 🚀 Деплой на Timeweb

## Вариант 1: Деплой через SSH (рекомендуется)

### Шаг 1: Подготовка на локальной машине

1. Убедитесь, что проект собирается:
```bash
cd tickets-backend
npm install
npm run build
```

2. Создайте файл `.env` на основе `.env.example`:
```bash
cp .env.example .env
# Отредактируйте .env с вашими реальными данными
```

### Шаг 2: Определение директории на сервере Timeweb

**Важно:** Выбор директории зависит от типа вашего тарифа Timeweb:

#### Вариант A: VPS/Выделенный сервер (рекомендуется)
Создайте директорию в домашней папке:
```bash
# После подключения через SSH:
cd ~
mkdir -p aviatickets-backend
cd aviatickets-backend
# Полный путь будет: ~/aviatickets-backend или /home/ваш_пользователь/aviatickets-backend
```

#### Вариант B: Виртуальный хостинг
Обычно используется директория `public_html` или `www`:
```bash
cd ~/public_html
# или
cd ~/www
mkdir -p aviatickets-backend
cd aviatickets-backend
```

#### Вариант C: Node.js хостинг Timeweb
Проверьте в панели управления, какая директория указана для Node.js приложений.
Обычно это может быть:
- `~/node-apps/ваше_приложение`
- `~/app`
- Или специальная директория, указанная в панели

**Как узнать текущую директорию после подключения:**
```bash
pwd  # Покажет текущую директорию
ls -la  # Покажет содержимое текущей директории
```

### Шаг 3: Загрузка на сервер Timeweb

1. Подключитесь к серверу через SSH:
```bash
ssh ваш_пользователь@ваш_сервер.timeweb.ru
# или
ssh ваш_пользователь@ваш_IP_адрес
```

2. Перейдите в нужную директорию (см. Шаг 2 выше):
```bash
# Для VPS (рекомендуется):
cd ~/aviatickets-backend

# Или создайте, если её нет:
mkdir -p ~/aviatickets-backend && cd ~/aviatickets-backend
```

3. Загрузите файлы проекта (через SFTP или git):
```bash
# Если используете git:
git clone ваш_репозиторий .

# Или загрузите через SFTP клиент (FileZilla, WinSCP и т.д.):
# - Подключитесь к серверу через SFTP
# - Перейдите в директорию ~/aviatickets-backend
# - Загрузите всю папку tickets-backend
```

### Шаг 4: Установка зависимостей и сборка

```bash
# Убедитесь, что вы в правильной директории:
pwd  # Должно показать путь к aviatickets-backend

# Перейдите в папку backend:
cd tickets-backend
# Или если вы загрузили файлы напрямую в aviatickets-backend:
# тогда файлы уже здесь, не нужно делать cd
npm install --production
npm run build
```

### Шаг 5: Настройка переменных окружения

```bash
# Убедитесь, что вы в директории tickets-backend:
cd ~/aviatickets-backend/tickets-backend
# или просто (если файлы в корне aviatickets-backend):
cd ~/aviatickets-backend

# Создайте .env файл:
cp .env.example .env
nano .env
# Или используйте ваш любимый редактор (vi, vim, etc.)
```

Заполните переменные:
- `PORT` - порт, на котором будет работать приложение (обычно 3000)
- `ONELYA_BASE_URL`, `ONELYA_LOGIN`, `ONELYA_PASSWORD`, `ONELYA_POS` - данные для Onelya API

### Шаг 6: Запуск через PM2 (рекомендуется)

Установите PM2 для управления процессом:
```bash
npm install -g pm2
```

Запустите приложение:
```bash
pm2 start dist/main.js --name aviatickets-backend
pm2 save
pm2 startup
```

Проверьте статус:
```bash
pm2 status
pm2 logs aviatickets-backend
```

### Шаг 7: Настройка Nginx (если нужен прокси)

Создайте конфигурацию Nginx:
```bash
sudo nano /etc/nginx/sites-available/aviatickets
```

Добавьте:
```nginx
server {
    listen 80;
    server_name ваш_домен.ru;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

Активируйте конфигурацию:
```bash
sudo ln -s /etc/nginx/sites-available/aviatickets /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

### Шаг 8: Настройка SSL (HTTPS)

Если у вас есть домен, настройте SSL через Let's Encrypt:
```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d ваш_домен.ru
```

## Вариант 2: Деплой через Docker

Если на Timeweb есть поддержка Docker:

1. На сервере создайте директорию (см. Шаг 2 выше) и загрузите файлы
2. Соберите и запустите контейнер:
```bash
# Перейдите в директорию проекта:
cd ~/aviatickets-backend/tickets-backend
# или если файлы в корне:
cd ~/aviatickets-backend
docker build -t aviatickets-backend .
docker run -d -p 3000:3000 --env-file .env --name aviatickets-backend aviatickets-backend
```

## Вариант 3: Деплой через панель Timeweb

1. Войдите в панель управления Timeweb
2. Перейдите в раздел "Node.js приложения" (если доступно)
3. Создайте новое приложение
4. Загрузите файлы проекта
5. Укажите точку входа: `dist/main.js`
6. Настройте переменные окружения в панели
7. Запустите приложение

## Проверка работы

После деплоя проверьте:
- API доступен: `http://ваш_домен.ru/api` (Swagger документация)
- Health check: `http://ваш_домен.ru/`
- Логи: `pm2 logs aviatickets-backend` или через панель Timeweb

## Обновление приложения

```bash
cd ~/aviatickets-backend/tickets-backend
git pull  # или загрузите новые файлы
npm install --production
npm run build
pm2 restart aviatickets-backend
```

## Полезные команды PM2

```bash
pm2 list                    # Список процессов
pm2 logs aviatickets-backend # Логи
pm2 restart aviatickets-backend # Перезапуск
pm2 stop aviatickets-backend   # Остановка
pm2 delete aviatickets-backend # Удаление
```

## Настройка автозапуска при перезагрузке сервера

```bash
pm2 startup
pm2 save
```

## Важные замечания

1. Убедитесь, что порт 3000 открыт в firewall Timeweb
2. Проверьте, что переменные окружения правильно настроены
3. Для production используйте `NODE_ENV=production`
4. Регулярно проверяйте логи на наличие ошибок
5. Настройте мониторинг и алерты (если доступно)

